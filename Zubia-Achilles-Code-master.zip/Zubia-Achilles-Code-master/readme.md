# Who Am I?

Aloha! Achilles here, I am a 2nd year Computer Science student from Los Banos Laguna. I am 20 years old, single and ready to mingle. 

# What is my Favorite Thing about ComSci

I have so many things that I love about the Computer Science subject. I really love this course because I can somewhat visualize how different softwares, gadgets and high-tech tools are being made. I can also visualize the physical world of games. 

# Expectations for this Class

I expect that I can learn a lot from this course. I also expect that I will enjoy learning on this course. 
